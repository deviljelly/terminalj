import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import {Event} from '../model/event.model';
import {HttpClient, HttpParams} from '@angular/common/http';
import {EventType} from '../model/event-type.enum';
import {Project} from '../model/project.model';

@Injectable({
  providedIn: 'root'
})
export class EventService {

  getEventsBySubjectUrl = '/getEventsBySubject';
  getEventsByObjectUrl = '/getEventsByObject';
  getEventsByTypeUrl = '/getEventsByType';

  constructor(private http: HttpClient) { }

  getEventsBySubject(subjectId: string): Observable<Event[]> {

    const parameters = new HttpParams()
      .set('subjectId', subjectId);

    return this.http.get<Event[]>(this.getEventsBySubjectUrl, {
        params: parameters
      }
    );

  }

  getEventsByObject(objectId: string): Observable<Event[]> {

    const parameters = new HttpParams()
      .set('objectId', objectId);

    return this.http.get<Event[]>(this.getEventsByObjectUrl, {
        params: parameters
      }
    );

  }

  getEventsByType(eventType: EventType): Observable<Event[]> {

    const x = EventType[eventType];

    const parameters = new HttpParams()
      .set('eventType', eventType);

    return this.http.get<Event[]>(this.getEventsByTypeUrl, {
        params: parameters
      }
    );

  }

}
