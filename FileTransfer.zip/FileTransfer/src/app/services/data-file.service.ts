import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import { DataFile } from '../model/data-file.model';
import { Observable } from 'rxjs';
import {App} from '../model/app.model';
import {Project} from '../model/project.model';
import {TableColumn} from '../model/table-column.model';
import {ProjectType} from '../model/project-type.enum';
import {ColumnMapping} from '../model/column-mapping.model';


@Injectable({ providedIn: 'root'})
export class DataFileService {

  dataFileUrl = '/getDataFile';
  getDataFileColumnsUrl = '/getDataFileColumns';
  getDataFileRowsUrl = '/getDataFileRows';
  getTargetDataColumnsUrl = '/getTargetDataColumns';
  getTargetDataRowsUrl = '/getTargetDataRows';

  constructor(private http: HttpClient) { }

  getFile(id: string): Observable<DataFile> {
    return this.http.post<DataFile>(this.dataFileUrl, id);
  }

  public getDataFileColumns(dataFileId: string): Observable<TableColumn[]> {

    const parameters = new HttpParams()
      .set('dataFileId', dataFileId);

    return this.http.get<TableColumn[]>(this.getDataFileColumnsUrl, {
        params: parameters
      }
    );

  }


  public getTargetDataColumns(projectType: ProjectType): Observable<TableColumn[]> {

    const parameters = new HttpParams()
      .set('projectType', projectType);

    return this.http.get<TableColumn[]>(this.getTargetDataColumnsUrl, {
        params: parameters
      }
    );

  }

  public getDataFileRows(dataFileId: string): Observable<any[]> {

    const parameters = new HttpParams()
      .set('dataFileId', dataFileId);

    return this.http.get<any[]>(this.getDataFileRowsUrl, {
        params: parameters
      }
    );

  }

  public getTargetDataRows(dataFileId: string, columnMappings: ColumnMapping[]): Observable<any[]> {

    const parameters = new HttpParams()
      .set('dataFileId', dataFileId)
      .set('columnMappingsString',  JSON.stringify(columnMappings));

    return this.http.get<any[]>(this.getTargetDataRowsUrl, {
        params: parameters
      }
    );

  }

}
