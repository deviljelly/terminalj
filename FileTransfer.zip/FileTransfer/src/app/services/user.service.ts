import { Injectable, OnInit} from '@angular/core';
import {User} from '../model/user.model';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Observable, Subject} from 'rxjs';
import {shareReplay} from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class UserService {

  loggedInUser = new Observable<User>();
  userCache: { [id: string]: Observable<User>; } = {};

  loggedInUserUrl = '/getLoggedInUser';
  getUserUrl = '/getUser';

  constructor(private http: HttpClient) {

  }

  public getUser(id: string): Observable<User> {

    if (this.userCache[id]) {
      return this.userCache[id];
    }

    const parameters = new HttpParams()
      .set('id', id);

    this.userCache[id] = this.http.get<User>(this.getUserUrl, {
        params: parameters
      }
    ).pipe(shareReplay(1));

    return this.userCache[id];

  }


  public getLoggedInUser(): Observable<User> {

    if (this.loggedInUser) {
      return this.loggedInUser;
    }

    this.loggedInUser = this.http.get<User>(this.loggedInUserUrl
    ).pipe(shareReplay(1));

    return this.loggedInUser;

  }

}
