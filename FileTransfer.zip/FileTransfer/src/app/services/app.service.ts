import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { App} from '../model/app.model';
import { Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AppService {

  getAppsForLoggedInUserUrl = '/getAppsForLoggedInUser';

  appsForLoggedInUserSubject = new Subject<App[]>();

  constructor(private http: HttpClient) { }

  public refreshAppsForLoggedInUser(): void {

    this.http.get<App[]>(this.getAppsForLoggedInUserUrl).subscribe(value => {
      this.appsForLoggedInUserSubject.next(value);
    });

  }

  public getAppsForLoggedInUser(): Subject<App[]> {
    return this.appsForLoggedInUserSubject;
  }


}
