import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Note} from '../model/note.model';
import {Project} from '../model/project.model';

@Injectable({ providedIn: 'root' })
export class ProjectNoteService {

  constructor(private http: HttpClient) { }

  getProjectNoteUrl = '/getProjectNotes';
  createProjectNoteUrl = '/createProjectNote';
  deleteProjectNoteUrl = '/deleteProjectNote';


  public createProjectNote(projectId: string): Observable<Note> {


    const parameters = new HttpParams()
      .set('projectId', projectId);

    return this.http.get<Note>(this.createProjectNoteUrl, {
        params: parameters
      }
    );

  }

  public getProjectNotes(projectId: string): Observable<Note[]> {

    const parameters = new HttpParams()
      .set('projectId', projectId);

    return this.http.get<Note[]>(this.getProjectNoteUrl, {
        params: parameters
      }
    );

  }

  public deleteProjectNote(project: Project, note: Note): Observable<Note> {

    const parameters = new HttpParams()
      .set('projectId', project.id)
      .set('noteId', note.id);

    return this.http.get<Note>(this.deleteProjectNoteUrl, {
        params: parameters
      }
    );

  }

}
