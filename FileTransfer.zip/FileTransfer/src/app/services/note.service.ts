import { Injectable } from '@angular/core';
import { HttpClient, HttpParams} from '@angular/common/http';
import { Observable } from 'rxjs';
import { DataFile } from '../model/data-file.model';
import { Note } from '../model/note.model';

@Injectable({ providedIn: 'root'})
export class NoteService {

  createNoteUrl = '/createNote';
  getNoteUrl = '/getNote';
  updateNoteUrl = '/updateNote';
  deleteNoteUrl = '/deleteNote';

  constructor(private http: HttpClient) {

  }

  getNote(noteId: string): Observable<Note> {

    return this.http.post<Note>(this.getNoteUrl, {id: noteId});

  }

  createNote(): Observable<Note> {

    return this.http.get<Note>(this.createNoteUrl);

  }

  updateNote(note: Note): Observable<Note> {

    return this.http.post<Note>(this.updateNoteUrl, note);

  }


  deleteNote(note: Note): Observable<boolean> {

    return this.http.post<boolean>(this.deleteNoteUrl, note);

  }


}
