import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Observable, Subject} from 'rxjs';
import {App} from '../model/app.model';
import {Project} from '../model/project.model';

@Injectable({ providedIn: 'root' })
export class ProjectService {

  createProjectUrl = '/createProject';
  getProjectUrl = '/getProject';
  getAppProjectsUrl = '/getAppProjects';
  updateProjectUrl = '/updateProject';

  projectsForCurrentAppSubject = new Subject<Project[]>();

  constructor(private http: HttpClient) { }


  public createProject(project: Project): Observable<Project> {

    return this.http.post<Project>(this.createProjectUrl, project);

  }


  public getProject(projectId: string): Observable<Project> {

    const parameters = new HttpParams()
        .set('projectId', projectId);

    return this.http.get<Project>(this.getProjectUrl, {
          params: parameters
        }
    );

  }

  public getAppProjects(app: App): Observable<Project[]> {

    const parameters = new HttpParams()
      .set('appId', app.id);

    return this.http.get<Project[]>(this.getAppProjectsUrl, {
        params: parameters
      }
      );

  }

  public updateProject(project: Project): Observable<Project> {

    return this.http.post<Project>(this.updateProjectUrl, project);

  }



}

