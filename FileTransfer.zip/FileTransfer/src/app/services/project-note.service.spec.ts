import { TestBed } from '@angular/core/testing';

import { ProjectNoteService } from './project-note.service';

describe('ProjectNoteService', () => {
  let service: ProjectNoteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProjectNoteService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
