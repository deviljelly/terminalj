import {Component, Input, OnInit, OnDestroy} from '@angular/core';
import {UserService} from '../services/user.service';
import {User} from '../model/user.model';
import {App} from '../model/app.model';
import {AppService} from '../services/app.service';

@Component({
  selector: 'app-titlebar',
  templateUrl: './titlebar.component.html',
  styleUrls: ['./titlebar.component.css']
})
export class TitlebarComponent implements OnInit {

  loggedInUser: User = new User();
  currentApp: App = new App();

  constructor(private userService: UserService, private appService: AppService) { }

  ngOnInit(): void {

    this.userService.getLoggedInUser().subscribe( user => { this.loggedInUser = user; });

  }

}
