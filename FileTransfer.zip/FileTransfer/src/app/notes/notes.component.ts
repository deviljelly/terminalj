import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {Note} from '../model/note.model';
import {NoteService} from '../services/note.service';
import {ProjectNoteService} from '../services/project-note.service';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.css']
})
export class NotesComponent implements OnInit {

  @Input() title: string = 'Notes';
  @Input() toggleable: boolean = true;
  @Input() notes: Note[];
  @Output() createNoteEvent = new EventEmitter<Note>();
  @Output() deleteNoteEvent = new EventEmitter<Note>();
  @Output() updateNoteEvent = new EventEmitter<Note>();

  constructor(private noteService: NoteService, private projectNoteService: ProjectNoteService) { }

  ngOnInit(): void {
  }

  public createNote(): void {

    this.createNoteEvent.next();

  }

  public deleteNote(note: Note): void {

    this.deleteNoteEvent.next(note);

    const elementID = this.notes.findIndex(element => element.id === note.id);
    this.notes.splice(elementID, 1);

  }

  public updateNote(note: Note): void {

    this.updateNoteEvent.next(note);

    const elementID = this.notes.findIndex(element => element.id === note.id);
    this.notes.splice(elementID, 1, note);

  }

}
