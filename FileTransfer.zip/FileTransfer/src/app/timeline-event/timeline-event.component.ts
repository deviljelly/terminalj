import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timeline-event',
  templateUrl: './timeline-event.component.html',
  styleUrls: ['./timeline-event.component.css']
})
export class TimelineEventComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
