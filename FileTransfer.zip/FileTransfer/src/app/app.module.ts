import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { SliderModule } from 'primeng/slider';
import { AppComponent } from './app.component';
import { RatingModule } from 'primeng/rating';
import { TableModule } from 'primeng/table';
import { TabViewModule} from 'primeng/tabview';
import { FieldsetModule } from 'primeng/fieldset';
import { PanelModule } from 'primeng/panel';
import { ToolbarModule } from 'primeng/toolbar';
import { FileUploadModule } from 'primeng/fileupload';
import { DropdownModule } from 'primeng/dropdown';
import { HttpClientModule } from '@angular/common/http';
import { EditorModule } from 'primeng/editor';
import { TitlebarComponent } from './titlebar/titlebar.component';
import { AccordionModule } from 'primeng/accordion';
import { ProjectsComponent } from './projects/projects.component';
import { ProjectComponent } from './project/project.component'
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { DialogModule } from 'primeng/dialog';
import { ToastModule } from 'primeng/toast';
import { NewProjectDialogComponent } from './new-project-dialog/new-project-dialog.component';
import { NoteComponent } from './note/note.component';
import { CardModule } from 'primeng/card';
import { InputTextareaModule} from 'primeng/inputtextarea';
import { TimelineModule} from 'primeng/timeline';
import { UserDisplayableNamePipe } from './pipes/user-displayable-name.pipe';
import { UserByIdPipe } from './pipes/user-by-id.pipe';
import { RippleModule } from 'primeng/ripple';
import { FullCalendarModule } from 'primeng/fullcalendar';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { RouterModule, Routes } from '@angular/router';
import { NotesComponent } from './notes/notes.component';
import { TimelineEventComponent } from './timeline-event/timeline-event.component';
import { TimelineEventsComponent } from './timeline-events/timeline-events.component';
import { SplitterModule } from 'primeng/splitter';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { NgxFilesizeModule } from 'ngx-filesize';
import { AppsComponent } from './apps/apps.component';
import { HomeComponent } from './home/home.component';


// const appRoutes: Routes = [
//  { path: 'apps', component: AppsComponent },
//  { path: 'projects', component: ProjectsComponent },
//  { path: 'project', component: ProjectComponent }
// ];


@NgModule({
  declarations: [
    AppComponent,
    TitlebarComponent,
    ProjectsComponent,
    NewProjectDialogComponent,
    ProjectComponent,
    NoteComponent,
    UserDisplayableNamePipe,
    UserByIdPipe,
    NotesComponent,
    TimelineEventComponent,
    TimelineEventsComponent,
    AppsComponent,
    HomeComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    SliderModule,
    ButtonModule,
    InputTextareaModule,
    PanelModule,
    AccordionModule,
    EditorModule,
    FieldsetModule,
    TabViewModule,
    TableModule,
    InputTextModule,
    CardModule,
    HttpClientModule,
    FileUploadModule,
    DropdownModule,
    RatingModule,
    TimelineModule,
    ToolbarModule,
    ToastModule,
    DynamicDialogModule,
    ConfirmDialogModule,
    DialogModule,
    FullCalendarModule,
    RippleModule,
    FontAwesomeModule,
    SplitterModule,
    MessagesModule,
    MessageModule,
    NgxFilesizeModule,
    RouterModule,
  ],
  providers: [ConfirmationService],
  bootstrap: [AppComponent],
})
export class AppModule { }
