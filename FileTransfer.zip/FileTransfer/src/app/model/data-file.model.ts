export class DataFile {

  id: string;
  name: string;
  data: string;
  createdBy: string;
  created: string;
  updatedBy: string;
  updated: string;

}
