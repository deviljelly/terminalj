import {TableColumn} from './table-column.model';

export class ColumnMapping {

  from: string;
  to: string;

}
