export class TimelineEvent {

}
