import {ProjectType} from './project-type.enum';

export class ProjectNote {

  projectId: string;
  noteId: ProjectType;
  lastUpdated: string;

}
