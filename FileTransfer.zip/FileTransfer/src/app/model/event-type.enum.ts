export enum EventType {

  ProjectCreated = 'ProjectCreated',
  StateChange = 'StateChange',
  NoteCreated = 'NoteCreated',
  NoteUpdated = 'NoteUpdated',
  NoteDeleted = 'NoteDeleted',
  DataUploaded = 'DataUploaded'

}
