import {EventType} from './event-type.enum';
import {ProjectState} from './project-state.enum';

export class Event {

  id: string;
  eventType: EventType;
  subjectId: string;
  objectId: string;
  fromState: ProjectState;
  toState: ProjectState;
  eventedBy: string;
  evented: string;

}
