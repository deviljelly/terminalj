import { TableColumn } from './table-column.model';

describe('TableColumn', () => {
  it('should create an instance', () => {
    expect(new TableColumn()).toBeTruthy();
  });
});
