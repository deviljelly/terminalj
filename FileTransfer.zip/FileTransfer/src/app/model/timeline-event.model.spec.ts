import { TimelineEvent } from './timeline-event.model';

describe('TimelineEvent', () => {
  it('should create an instance', () => {
    expect(new TimelineEvent()).toBeTruthy();
  });
});
