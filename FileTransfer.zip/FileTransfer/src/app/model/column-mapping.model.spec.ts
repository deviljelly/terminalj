import { ColumnMapping } from './column-mapping.model';

describe('ColumnMapping', () => {
  it('should create an instance', () => {
    expect(new ColumnMapping()).toBeTruthy();
  });
});
