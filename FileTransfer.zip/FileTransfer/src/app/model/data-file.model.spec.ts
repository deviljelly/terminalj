import { DataFile } from './data-file.model';

describe('DataFile', () => {
  it('should create an instance', () => {
    expect(new DataFile()).toBeTruthy();
  });
});
