export enum ProjectType {

  Entitlements = 'Entitlements',
  Accounts = 'Accounts',
  Assignemnts = 'Assignments'

}
