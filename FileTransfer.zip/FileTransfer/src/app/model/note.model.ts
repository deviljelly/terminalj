export class Note {

  id: string;
  title: string;
  body: string;
  createdBy: string;
  created: string;
  updatedBy: string;
  updated: string;

}
