export class User {

  id: string;
  userId: string;
  userName: string;
  displayableName: string;
  createdBy: string;
  created: string;
  updatedBy: string;
  updated: string;

}
