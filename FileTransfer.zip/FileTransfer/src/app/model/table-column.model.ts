export class TableColumn {

  field: string;
  header: string;

}
