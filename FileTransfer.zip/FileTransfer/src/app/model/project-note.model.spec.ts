import { ProjectNote } from './project-note.model';

describe('ProjectNote', () => {
  it('should create an instance', () => {
    expect(new ProjectNote()).toBeTruthy();
  });
});
