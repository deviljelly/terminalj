export enum ProjectState {

  Design = 'Design',
  Approval = 'Approval',
  Approved = 'Approved',
  Submitted = 'Submitted',
  Scheduled = 'Scheduled',
  Running = 'Running',
  Successful = 'Successful',
  Failed = 'Failed',
  Archived = 'Archived'

}
