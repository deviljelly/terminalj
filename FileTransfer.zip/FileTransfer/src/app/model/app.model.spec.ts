import { App } from './app.model';

describe('App', () => {
  it('should create an instance', () => {
    expect(new App()).toBeTruthy();
  });
});
