export class App {

  id: string;
  name: string;
  description: string;
  appManager: string;
  createdBy: string;
  created: string;
  updatedBy: string;
  updated: string;

}
