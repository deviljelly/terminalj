import {ProjectType} from './project-type.enum';
import {ProjectState} from './project-state.enum';
export class Project {

  id: string;
  projectType: ProjectType;
  projectState: ProjectState;
  number: string;
  name: string;
  description: string;
  appId: string;
  dataFileId: string;
  columnMapping: string;
  createdBy: string;
  created: Date;
  updatedBy: string;
  updated: Date;

}
