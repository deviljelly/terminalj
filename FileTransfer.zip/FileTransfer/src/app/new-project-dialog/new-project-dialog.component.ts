import {Component, OnInit} from '@angular/core';
import {DynamicDialogConfig, DynamicDialogRef} from 'primeng/dynamicdialog';
import {Project} from '../model/project.model';
import {ProjectType} from '../model/project-type.enum';
import {SelectItem} from 'primeng/api';

@Component({
  selector: 'app-new-project-dialog',
  templateUrl: './new-project-dialog.component.html',
  styleUrls: ['./new-project-dialog.component.css']
})
export class NewProjectDialogComponent implements OnInit {


  projectTypes: SelectItem[];
  project: Project;
  descriptionInvalid: boolean;
  descriptionInvalidClass: string;
  nameInvalid: boolean;
  nameInvalidClass: string;

  selectedProjectType: any;


  constructor(private ref: DynamicDialogRef, private config: DynamicDialogConfig) { }

  ngOnInit(): void {

    this.project = new Project();
    this.project.projectType = ProjectType.Entitlements;


    this.checkValidity();
    this.selectedProjectType = ProjectType.Entitlements;
    this.projectTypes = Object.keys(ProjectType).map(key => ({ label: key, value: ProjectType[key]}));

  }

  onProjectChanged(event): void {
    this.checkValidity();
  }

  onDropDownChanged(event): void {
    console.log(this.selectedProjectType);
    this.checkValidity();
  }


  checkValidity(): void {

    console.log('checkValidity: ' + this.project);

    if ( typeof this.project.name !== 'undefined' && this.project.name ) {
      this.nameInvalid = false;
      this.nameInvalidClass = '';
    } else {
      this.nameInvalid = true;
      this.nameInvalidClass = 'ng-invalid ng-dirty';
    }

    if ( typeof this.project.description !== 'undefined' && this.project.description ) {
      this.descriptionInvalid = false;
      this.descriptionInvalidClass = '';
    } else {
      this.descriptionInvalid = true;
      this.descriptionInvalidClass = 'ng-invalid ng-dirty';
    }

  }

  close(result: string): void {
    console.log(this.selectedProjectType);

    this.ref.close(null);
  }

  save(): void {
    console.log(this.selectedProjectType);
    this.ref.close(this.project);

 }

  cancel(): void {
    console.log(this.selectedProjectType);
    this.ref.close(null);
  }


}
