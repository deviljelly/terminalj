import {Component, Input, OnInit, Output, EventEmitter} from '@angular/core';
import {FormControl, NgForm} from '@angular/forms';
import { Note } from '../model/note.model';
import { NoteService} from '../services/note.service';
import {ToolbarModule} from 'primeng/toolbar';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.css'],
})
export class NoteComponent implements OnInit {

  @Input() note: Note;
  @Output() deleteNoteEvent = new EventEmitter<Note>();
  @Output() updateNoteEvent = new EventEmitter<Note>();


  undoNote: Note;

  body: string;

  noteClass = 'ng-invalid ng-dirty';

  editable = true;
  editMode = false;

  collapsed = false;

  constructor(private noteService: NoteService) {

  }

  ngOnInit(): void {

    this.undoNote = this.note;

  }

  updateNote(): void  {

    this.noteService.updateNote(this.note).subscribe( note => {
      this.note = note;
      this.updateNoteEvent.next(this.note);
      this.editMode = false;
    } );

    this.editable = false;

  }

  editNote(): void  {
    this.editMode = true;
  }


  cancelEdit(): void  {
    this.editMode = false;
  }

  deleteNote(): void  {

    this.deleteNoteEvent.next(this.note);

  }

}
