import { Pipe, PipeTransform } from '@angular/core';
import {UserService} from '../services/user.service';
import {User} from '../model/user.model';

@Pipe({
  name: 'userDisplayableName',
  pure: true
})
export class UserDisplayableNamePipe implements PipeTransform {

  constructor(private userService: UserService) {
  }

  transform(user: User): string {

    if (user) {
      return user.displayableName;
    } else {
      return 'Unknown';
    }

  }

}
