import { Pipe, PipeTransform } from '@angular/core';
import { shareReplay } from 'rxjs/operators';
import { User } from '../model/user.model';
import { UserService } from '../services/user.service';
import { Observable } from 'rxjs';

@Pipe({
  name: 'userById',
  pure: false
})
export class UserByIdPipe implements PipeTransform {

  constructor(private userService: UserService) {
  }

  transform(id: string): Observable<User> {

    return this.userService.getUser(id);

  }

}
