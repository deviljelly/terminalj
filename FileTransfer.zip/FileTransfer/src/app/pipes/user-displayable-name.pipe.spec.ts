import { UserDisplayableNamePipe } from './user-displayable-name.pipe';

describe('UserDisplayableNamePipe', () => {
  it('create an instance', () => {
    const pipe = new UserDisplayableNamePipe();
    expect(pipe).toBeTruthy();
  });
});
