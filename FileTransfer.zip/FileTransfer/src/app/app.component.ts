import { Component, OnInit, AfterContentChecked, AfterContentInit, AfterViewInit } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { DataFileService } from './services/data-file.service';
import { UserService } from './services/user.service';
import { DataFile } from './model/data-file.model';
import { User } from './model/user.model';
import { Observable, Subject } from 'rxjs';
import { App } from './model/app.model';
import { AppService } from './services/app.service';
import { Project } from './model/project.model';
import { DialogService } from 'primeng/dynamicdialog';
import { PrimeNGConfig } from 'primeng/api';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  providers: [ DataFileService, UserService, DialogService ],
  styleUrls: ['./app.component.css']

})

export class AppComponent implements OnInit, AfterViewInit, AfterContentInit, AfterContentChecked {

  loggedInUser: User = new User();
  appsForLoggedInUser: App[];
  currentApp: App ;
  projectsForCurrentApp: Project[];


  constructor(private primengConfig: PrimeNGConfig, private userService: UserService, private fileService: DataFileService, private appService: AppService, private http: HttpClient) {
  }

  ngOnInit(): void {

    this.primengConfig.ripple = true;

    this.userService.getLoggedInUser().subscribe(user => this.loggedInUser = user);

    this.appService.getAppsForLoggedInUser().subscribe(value => this.appsForLoggedInUser = value);

    this.appService.refreshAppsForLoggedInUser();


  }


  ngAfterViewInit(): void {
  }

  ngAfterContentChecked(): void {
  }

  ngAfterContentInit(): void {
  }



}
