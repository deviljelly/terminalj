import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timeline-events',
  templateUrl: './timeline-events.component.html',
  styleUrls: ['./timeline-events.component.css']
})
export class TimelineEventsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
