import { Component, OnDestroy, OnInit } from '@angular/core';
import { Project } from '../model/project.model';
import { ProjectType } from '../model/project-type.enum';
import { App } from '../model/app.model';
import { ProjectService } from '../services/project.service';
import { Subject } from 'rxjs';
import { DialogService } from 'primeng/dynamicdialog';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { NewProjectDialogComponent } from '../new-project-dialog/new-project-dialog.component';
import {Message, MessageService} from 'primeng/api';


@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.css'],
  providers: [DialogService, MessageService]
})

export class ProjectsComponent implements OnInit, OnDestroy {

  currentApp: App = new App();

  statuses: string[] = Object.values(ProjectType);

  body: string;

  projects: Project[] = [];

  projectsForAppSubject = new Subject<Project[]>();

  constructor(private messageService: MessageService, private projectService: ProjectService, private dialogService: DialogService, private router: Router, private activatedRoute: ActivatedRoute) { }

  ref: DynamicDialogRef;


  ngOnInit(): void {

   this.currentApp.id = 'ff80808176d3211f0176d322b9120008';
   this.currentApp.name = 'TestApp';
   this.currentApp.description = 'Test Application';
   this.currentApp.appManager = 'ff80808176d8c0e40176d8c10e240004';

   this.projectService.getAppProjects(this.currentApp).subscribe(projects =>  {
     this.projects = projects;
   }

   );

  }


  show(): void {
    this.ref = this.dialogService.open(NewProjectDialogComponent, {
      header: 'New Project',
      width: '70%',
      contentStyle: {'max-height': '500px', overflow: 'auto'},
      baseZIndex: 10000
    });

    this.ref.onClose.subscribe((project: Project) => {

      if ( typeof project !== 'undefined' && project ) {

        project.appId = this.currentApp.id;

        this.projectService.createProject(project).subscribe(createdProject => {

          this.projectService.getProject(createdProject.id).subscribe(newProject => {
            this.messageService.add({severity: 'success', summary: 'Project Created', detail: newProject.projectType + ' project number ' + newProject.number + ' created.'});
            this.projects.push(newProject);

          } );

        } );

      }

    });

  }

  onBasicUpload($event): void {
  }


  ngOnDestroy(): void {
    if (this.ref) {
      this.ref.close();
    }
  }

  onRowSelect(event): void {

    const  project: Project = event.data as Project;
    this.router.navigate(['/project'], { state: project});

  }

  onRowUnselect(event): void {
  }
}
