import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationStart } from '@angular/router';
import { Project } from '../model/project.model';
import { Note } from '../model/note.model';
import { Event } from '../model/event.model';
import { ProjectNoteService } from '../services/project-note.service';
import { ProjectService } from '../services/project.service';
import { interval, Subscription } from 'rxjs';
import { EventService } from '../services/event.service';
import { TimelineEvent } from '../model/timeline-event.model';
import { DataFileService } from '../services/data-file.service';
import { Message, MessageService } from 'primeng/api';
import { DialogService } from 'primeng/dynamicdialog';
import { DataFile } from '../model/data-file.model';
import { ColumnMapping } from '../model/column-mapping.model';




@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.scss'],
  providers: [DialogService, MessageService]
})

export class ProjectComponent implements OnInit, OnDestroy {

  project: Project = new Project();

  projectChanged = false;

  private saveTimer: Subscription;

  timelineEvents: TimelineEvent[];

  targetColumn: any[];

  newEvents: Event[] = [];

  sourceDataColumns: any[];
  sourceDataRows: any[];

  targetDataColumns: any[];
  targetDataRows: any[];

  columnMappings: ColumnMapping[];

  notes: Note[] = [];



  constructor( private messageService: MessageService, private eventService: EventService, private projectService: ProjectService, private projectNoteService: ProjectNoteService, private dataFileService: DataFileService, private router: Router, private activatedRoute: ActivatedRoute) {

    if (this.router.getCurrentNavigation().extras.state) {
      this.project = this.router.getCurrentNavigation().extras.state as Project;

    }

  }

  ngOnInit(): void {

    this.targetColumn = [];


    // this.activatedRoute.params.subscribe((params) => {this.project = });

    this.eventService.getEventsBySubject(this.project.id).subscribe( events => this.newEvents = events);

    this.saveTimer = interval(3000).subscribe(value => {
        this.updateProject();
    });

    this.projectNoteService.getProjectNotes(this.project.id).subscribe(value => this.notes = value);

    this.dataFileService.getDataFileColumns(this.project.dataFileId).subscribe(value => { this.sourceDataColumns = value;


      }


    );
    this.dataFileService.getDataFileRows(this.project.dataFileId).subscribe(value => { this.sourceDataRows = value; } );

    this.dataFileService.getTargetDataColumns(this.project.projectType).subscribe(value => { this.targetDataColumns = value;

       this.columnMappings = [];
      for (let i = 0; i < this.targetDataColumns.length; i++) {

        const columnMapping: ColumnMapping = new ColumnMapping();
        columnMapping.from = this.targetDataColumns[i].header;
        columnMapping.to = '';

        this.columnMappings.push(columnMapping);

        console.log(this.targetDataColumns[i].header);

      }

      this.updateColumnMapping();

    } );



  }

  createProjectNote(): void {

     this.projectNoteService.createProjectNote(this.project.id).subscribe(note => this.notes.push(note));

  }

  deleteProjectNote(note: Note): void {

    console.log('Project: deleteProjectNote: ' + note.id);

    this.projectNoteService.deleteProjectNote(this.project, note).subscribe();

  }

  updateProjectNote(note: Note): void {

    this.messageService.add({severity: 'success', summary: 'Note Updated', detail: 'Note ' + note.title + ' updated.' } );

  }


  back(): void {
    console.log('back');
    this.router.navigate(['/projects']);
  }

  ngOnDestroy(): void {

    this.saveTimer.unsubscribe();
    this.updateProject();

  }

  onTabChanged(event): void {
  }

  updateProject(): void {

    if (this.projectChanged) {
      this.projectService.updateProject(this.project).subscribe(project => {
        this.project = project;
        this.projectChanged = false;
        this.messageService.add({severity: 'success', summary: 'Project Updated', detail: 'Project number #' + this.project.number + ' updated.' } );

      });
    }

  }


  public onDataFileUpload(event): void  {

    const fileName: string = event.files[0].name;
    const fileSize: number = event.files[0].size;

    const datafile = event.originalEvent.body as DataFile;
    console.log(event.originalEvent.body);

    this.messageService.add({severity: 'success', summary: 'Data Uploaded', detail: '' + fileName + ' (' + this.formatBytes(fileSize) + ')' } );

    this.project.dataFileId = datafile.id;


    this.dataFileService.getDataFileColumns(this.project.dataFileId).subscribe(sourceColumns => {
      this.sourceDataColumns = sourceColumns;
    }


    );

    this.dataFileService.getDataFileRows(this.project.dataFileId).subscribe(value => { this.sourceDataRows = value; } );

    this.dataFileService.getTargetDataColumns(this.project.projectType).subscribe(value => { this.targetDataColumns = value;
      this.columnMappings = [];

      for (let i = 0; i < this.targetDataColumns.length; i++) {

        const columnMapping: ColumnMapping = new ColumnMapping();
        columnMapping.from = this.targetDataColumns[i].header;
        columnMapping.to = '';
        this.columnMappings.push(columnMapping);

      }

    } );

    this.projectService.updateProject(this.project).subscribe(project => this.project = project);

  }
  public onDataFileUploadError(event): void  {

    console.log('onDataFileUploadError: ' + event.toString());

  }

  onProjectChanged(event): void {
    this.projectChanged = true;
  }

  testTransform(): void {

    this.project.columnMapping = JSON.stringify(this.columnMappings);

    this.projectService.updateProject(this.project).subscribe( project => this.project = project);

    this.dataFileService.getTargetDataRows(this.project.dataFileId, this.columnMappings).subscribe( value => { this.targetDataRows = value; console.log('testTransForm: ' + value ); } );

//    console.log(JSON.stringify(this.columnMappings));

  }

  createTimelineEvents(events: Event[]): TimelineEvent[] {
    return null;
  }

   updateColumnMapping(): void {

    const xxx: ColumnMapping[] = eval('(' + this.project.columnMapping + ')');

    this.columnMappings = eval('(' + this.project.columnMapping + ')');


  }

  formatBytes(bytes: number, decimals: number = 2): string {

    if (bytes === 0) {
      return '0 Bytes';
    }

    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];

  }

}
