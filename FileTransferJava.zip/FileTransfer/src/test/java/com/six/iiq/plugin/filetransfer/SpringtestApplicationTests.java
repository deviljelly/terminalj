package com.six.iiq.plugin.filetransfer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileTransferApplicationTests {

    @Test
    void contextLoads() {
    }

}
