package com.six.iiq.plugin.filetransfer.repository;

import com.six.iiq.plugin.filetransfer.entities.Project;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
import org.springframework.data.rest.webmvc.config.RepositoryRestConfigurer;
import org.springframework.web.servlet.config.annotation.CorsRegistry;

import java.util.List;

public interface ProjectRepository extends CrudRepository<Project, String> {


    @RestResource(exported = false)
    void deleteById(String id);

    @Configuration
    static class RepositoryConfig implements RepositoryRestConfigurer {

        @Override
        public void configureRepositoryRestConfiguration(RepositoryRestConfiguration config, CorsRegistry corsRegistry) {
            config.exposeIdsFor(Project.class);
        }

    }

    @Query("SELECT p FROM Project p WHERE p.appId = :appId")
    public List<Project> findAllProjectsForApp(@Param("appId") String appId);

}