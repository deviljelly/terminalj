package com.six.iiq.plugin.filetransfer.enums;

public enum EventType {

    ProjectCreated("ProjectCreated"),
    StateChange("StateChange"),
    NoteCreated("NoteCreated"),
    NoteUpdated("NoteUpdated"),
    NoteDeleted("NoteDeleted"),
    DataUploaded("DataUploaded");

    public final String label;

    private EventType(String label) {
        this.label = label;
    }

}
