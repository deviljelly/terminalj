package com.six.iiq.plugin.filetransfer.controller;

import com.six.iiq.plugin.filetransfer.Context;
import com.six.iiq.plugin.filetransfer.entities.App;
import com.six.iiq.plugin.filetransfer.entities.User;
import com.six.iiq.plugin.filetransfer.repository.AppRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class AppController {

    @Autowired
    private AppRepository appRepository;


    @RequestMapping("/getAppsForLoggedInUser")
    public List<App> getAppsForLoggedInUser() {

        User loggedInUser = Context.getSession().getLoggedInUser();

        return appRepository.findAllAppsForUser(loggedInUser.getId());

    }

};




