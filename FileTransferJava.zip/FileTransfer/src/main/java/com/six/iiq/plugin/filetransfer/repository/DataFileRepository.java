package com.six.iiq.plugin.filetransfer.repository;

import com.six.iiq.plugin.filetransfer.entities.DataFile;
import org.springframework.data.repository.CrudRepository;

public interface DataFileRepository extends CrudRepository<DataFile, String> {

}
