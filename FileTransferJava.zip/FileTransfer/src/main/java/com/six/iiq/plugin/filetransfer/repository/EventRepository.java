package com.six.iiq.plugin.filetransfer.repository;

import com.six.iiq.plugin.filetransfer.entities.App;
import com.six.iiq.plugin.filetransfer.entities.Event;
import com.six.iiq.plugin.filetransfer.enums.EventType;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EventRepository extends CrudRepository<Event, String> {

    @Query("SELECT e FROM Event e WHERE e.subjectId = :subjectId")
    public List<Event> findBySubject(@Param("subjectId") String subjectId);

    @Query("SELECT e FROM Event e WHERE e.objectId = :objectId")
    public List<Event> findByObject(@Param("objectId") String objectId);

    @Query("SELECT e FROM Event e WHERE e.eventType = :eventType")
    public List<Event> findByType(@Param("eventType") EventType eventType);

}
