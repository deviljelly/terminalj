package com.six.iiq.plugin.filetransfer.entities;


import org.hibernate.annotations.GenericGenerator;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;

import javax.persistence.*;

@Entity
@Table( name="project_note" )
@Audited
@AuditTable("project_note_audit")
public class ProjectNote {

    @Id
    @Column( name = "id", columnDefinition="CHAR(32)", nullable = false )
    @GeneratedValue( generator = "uuid" )
    @GenericGenerator( name = "uuid", strategy = "uuid" )
    private String id;

    @Column(name = "project_id", columnDefinition="CHAR(32)", nullable = false)
    private String projectId;

    @Column(name = "note_id", columnDefinition="CHAR(32)", nullable = false)
    private String noteId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getNoteId() {
        return noteId;
    }

    public void setNoteId(String noteId) {
        this.noteId = noteId;
    }
}
