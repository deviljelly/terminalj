package com.six.iiq.plugin.filetransfer.dto;

import com.six.iiq.plugin.filetransfer.enums.ProjectState;
import com.six.iiq.plugin.filetransfer.enums.ProjectType;

import java.time.LocalDateTime;

public class ProjectDto {


    private String id;
    ProjectType projectType;
    ProjectState projectState;
    int number;
    String name;
    String description;
    String appId;
    String dataFileId;
    String columnMapping;
    private String createdBy;
    private LocalDateTime created;
    private String updatedBy;
    private LocalDateTime updated;

}
