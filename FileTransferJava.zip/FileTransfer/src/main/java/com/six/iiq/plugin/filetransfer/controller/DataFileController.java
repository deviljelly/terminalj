package com.six.iiq.plugin.filetransfer.controller;

import com.six.iiq.plugin.filetransfer.entities.*;
import com.six.iiq.plugin.filetransfer.enums.EventType;
import com.six.iiq.plugin.filetransfer.enums.ProjectType;
import com.six.iiq.plugin.filetransfer.repository.DataFileRepository;
import com.six.iiq.plugin.filetransfer.repository.EventRepository;
import com.six.iiq.plugin.filetransfer.repository.ProjectRepository;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.util.*;
import org.apache.commons.csv.CSVFormat;

@RestController
public class DataFileController {

    public static int count=1;

    @Autowired
    private DataFileRepository dataFileRepository;
    @Autowired
    private EventRepository eventRepository;
    @Autowired
    private ProjectRepository projectRepository;


    public static List<TableColumn> ENTITLEMENTS_COLUMNS = new ArrayList();
    public static List<TableColumn> ACCOUNTS_COLUMNS = new ArrayList();
    public static List<TableColumn> ASSIGNMENTS_COLUMNS = new ArrayList();


    static {

        ENTITLEMENTS_COLUMNS.add(new TableColumn("ApplicationName","ApplicationName"));
        ENTITLEMENTS_COLUMNS.add(new TableColumn("EntitlementName","EntitlementName"));
        ENTITLEMENTS_COLUMNS.add(new TableColumn("Description","Description"));
        ENTITLEMENTS_COLUMNS.add(new TableColumn("OwnerName","OwnerName"));
        ENTITLEMENTS_COLUMNS.add(new TableColumn("FulfillerName","FulfillerName"));


        ACCOUNTS_COLUMNS.add(new TableColumn("IdentityName","IdentityName"));
        ACCOUNTS_COLUMNS.add(new TableColumn("ApplicationName","ApplicationName"));
        ACCOUNTS_COLUMNS.add(new TableColumn("AccountStatus","AccountStatus"));

        ASSIGNMENTS_COLUMNS.add(new TableColumn("IdentityName","IdentityName"));
        ASSIGNMENTS_COLUMNS.add(new TableColumn("ApplicationName","ApplicationName"));
        ASSIGNMENTS_COLUMNS.add(new TableColumn("EntitlementName","EntitlementName"));


    }



    @RequestMapping("/getDataFileColumns")
    public List<TableColumn> getDataFileColumns(@RequestParam String dataFileId) {

        Optional<DataFile> dataFileOptional = dataFileRepository.findById(dataFileId);

        ArrayList<TableColumn> tableColumns = new ArrayList<>();

        if (dataFileOptional.isPresent()) {

            DataFile dataFile = dataFileOptional.get();
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(dataFile.getData());
            InputStreamReader inputStreamReader = new InputStreamReader(byteArrayInputStream);

            try {

                CSVParser csvParser = new CSVParser(inputStreamReader, CSVFormat.RFC4180.withFirstRecordAsHeader().withDelimiter(','));

                Map<String, Integer> headerMap = csvParser.getHeaderMap();

                int numberOfColumns = headerMap.size();

                Set<String> headerNames = headerMap.keySet();

                for(String headerName : headerNames) {

                    tableColumns.add(new TableColumn(headerName, headerName));
                }


            } catch(Exception e) {
                System.out.println(e);
            }

        }

        return tableColumns;

    }


    @RequestMapping("/getDataFileRows")
    public List<Map<String, String>> getDataFileRows(@RequestParam String dataFileId) {

        Optional<DataFile> dataFileOptional  = dataFileRepository.findById(dataFileId);

        ArrayList<Map<String, String>> tableRows = new ArrayList<>();

        if (dataFileOptional.isPresent()) {

            DataFile dataFile = dataFileOptional.get();
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(dataFile.getData());
            InputStreamReader inputStreamReader = new InputStreamReader(byteArrayInputStream);

            try {

                CSVParser csvParser = new CSVParser(inputStreamReader, CSVFormat.RFC4180.withFirstRecordAsHeader().withDelimiter(','));


                Iterable<CSVRecord> records = csvParser.getRecords();
                for (CSVRecord record : records) {
                    tableRows.add(record.toMap());
                }

            } catch(Exception e) {
                System.out.println(e);
            }

        }

        return tableRows;

    }


    @RequestMapping("/getTargetDataColumns")
    public List<TableColumn> getTargetDataColumns(@RequestParam ProjectType projectType) {

        List<TableColumn> targetDataColumns = new ArrayList();

        switch (projectType) {
            case Entitlements:
                targetDataColumns = ENTITLEMENTS_COLUMNS;
                break;
            case Accounts:
                targetDataColumns = ACCOUNTS_COLUMNS;
                break;
            case Assignments:
                targetDataColumns = ASSIGNMENTS_COLUMNS;
                break;
            default:

        }

        return targetDataColumns;

    }


    @RequestMapping("/getTargetDataRows")
    public List<Map<String, String>> getTargetDataRows(@RequestParam String dataFileId, @RequestParam String columnMappingsString) {

        List<ColumnMapping> columnMappings = ColumnMapping.fromJSON(columnMappingsString);

        Optional<DataFile> dataFileOptional  = dataFileRepository.findById(dataFileId);

        ArrayList<Map<String, String>> tableRows = new ArrayList<>();

        if (dataFileOptional.isPresent()) {

            DataFile dataFile = dataFileOptional.get();
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(dataFile.getData());
            InputStreamReader inputStreamReader = new InputStreamReader(byteArrayInputStream);

            try {

                CSVParser csvParser = new CSVParser(inputStreamReader, CSVFormat.RFC4180.withFirstRecordAsHeader().withDelimiter(','));

                Iterable<CSVRecord> records = csvParser.getRecords();

                for (CSVRecord record : records) {

                    Map<String, String> mappedRecord = new LinkedHashMap<String, String>();

                    for(ColumnMapping columnMapping : columnMappings) {

                        mappedRecord.put(columnMapping.getFrom(), record.get(columnMapping.getTo()));

                    }

                    tableRows.add(mappedRecord);
                }

            } catch(Exception e) {
                System.out.println(e);
            }

        }

        return tableRows;

    }




    //    @RequestMapping(value="/uploadDataFile",  method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @RequestMapping(value="/uploadDataFile",  method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity uploadDataFile(@RequestParam("uploadedDataFile") MultipartFile uploadedDataFile) {

        DataFile newDataFile = new DataFile();

        newDataFile.setName(uploadedDataFile.getName());

        try {

            newDataFile.setData(uploadedDataFile.getInputStream().readAllBytes());

        } catch (Exception e) {

            System.out.println(e);
        }

        newDataFile = dataFileRepository.save(newDataFile);

        return ResponseEntity.status(HttpStatus.CREATED).body(newDataFile.getMetadata());

    }

}
