package com.six.iiq.plugin.filetransfer.entities;

public class TableColumn {

    private String field;
    private String header;

    public TableColumn() {

    }

    public TableColumn(String field, String header) {
        this.field = field;
        this.header = header;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

}
