package com.six.iiq.plugin.filetransfer.entities;


import com.six.iiq.plugin.filetransfer.Context;
import com.six.iiq.plugin.filetransfer.enums.ProjectState;
import com.six.iiq.plugin.filetransfer.enums.ProjectType;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "project")
@Audited
@AuditTable("project_audit")
public class Project {


    @Id
    @Column(name = "id", columnDefinition="CHAR(32)", unique = true, nullable = false)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator( name = "uuid", strategy = "uuid" )
    private String id;

    @Column(name = "project_type", columnDefinition = "ENUM('Entitlements', 'Accounts', 'Assignments')", nullable = false)
    @Enumerated(EnumType.STRING)
    ProjectType projectType;

    @Column(name = "project_state", columnDefinition = "ENUM('Design', 'Approval', 'Approved', 'Rejected', 'Submitted', 'Scheduled', 'Running', 'Failed', 'Archived')", nullable = false)
    @Enumerated(EnumType.STRING)
    ProjectState projectState;

    @Column(name = "number", columnDefinition="INT(6)", unique = true, nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    int number;

    @Column(name = "name", columnDefinition="VARCHAR(128)", nullable = false)
    String name;

    @Column(name = "description", columnDefinition="VARCHAR(1024)", nullable = false)
    String description;

    @Column(name = "app_id", columnDefinition="CHAR(32)", nullable = false)
    String appId;

    @Column(name = "data_file_id", columnDefinition="CHAR(32)")
    String dataFileId;

    @Column(name = "column_mapping", columnDefinition="VARCHAR(4096)")
    String columnMapping;

    @Column(name = "created_by", columnDefinition="CHAR(32)", nullable = false)
    private String createdBy;

    @Column(name = "created", columnDefinition="DATETIME(6)", nullable = false)
    private LocalDateTime created;

    @Column(name = "updated_by", columnDefinition="CHAR(32)")
    private String updatedBy;

    @Column(name = "updated", columnDefinition="DATETIME(6)")
    private LocalDateTime updated;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ProjectType getProjectType() {
        return projectType;
    }

    public void setProjectType(ProjectType projectType) {
        this.projectType = projectType;
    }

    public ProjectState getProjectState() {
        return projectState;
    }

    public void setProjectState(ProjectState projectState) {
        this.projectState = projectState;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {

        this.description = description;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getDataFileId() {
        return dataFileId;
    }

    public void setDataFileId(String dataFileId) {
        this.dataFileId = dataFileId;
    }

    public String getColumnMapping() {
        return columnMapping;
    }

    public void setColumnMapping(String columnMapping) {
        this.columnMapping = columnMapping;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreated() {
        return created;
    }

    public void setCreated(LocalDateTime created) {
        this.created = created;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public LocalDateTime getUpdated() {
        return updated;
    }

    public void setUpdated(LocalDateTime updated) {
        this.updated = updated;
    }

    @PrePersist
    protected void onPrePersist() {
        this.createdBy = Context.getSession().getLoggedInUser().getId();
        this.created = LocalDateTime.now();
    }

    @PreUpdate
    protected void onPreUpdate() {
        this.updatedBy = Context.getSession().getLoggedInUser().getId();
        this.updated = LocalDateTime.now();
    }


}
