package com.six.iiq.plugin.filetransfer.entities;

import com.six.iiq.plugin.filetransfer.Context;
import com.six.iiq.plugin.filetransfer.enums.EventType;
import com.six.iiq.plugin.filetransfer.enums.ProjectState;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "event")
@Audited
@AuditTable("event_audit")
public class Event {
    @Id
    @Column(name = "id", columnDefinition="CHAR(32)", nullable = false)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(
            name = "uuid",
            strategy = "uuid"
    )
    private String id;

    @Column(name = "event_type")
    @Enumerated(EnumType.STRING)
    private EventType eventType;

    @Column(name = "subject_id", columnDefinition="CHAR(32)", nullable = false)
    private String subjectId;

    @Column(name = "object_id", columnDefinition="CHAR(32)", nullable = false)
    private String objectId;

    @Column(name = "from_state")
    @Enumerated(EnumType.STRING)
    private ProjectState fromState;

    @Column(name = "to_state")
    @Enumerated(EnumType.STRING)
    private ProjectState toState;

    @Column(name = "evented_by", columnDefinition="CHAR(32)", nullable = false)
    private String eventedBy;

    @Column(name = "evented", nullable = false)
    private LocalDateTime evented;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public EventType getEventType() {
        return eventType;
    }

    public void setEventType(EventType eventType) {
        this.eventType = eventType;
    }

    public String getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(String subjectId) {
        this.subjectId = subjectId;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public ProjectState getFromState() {
        return fromState;
    }

    public void setFromState(ProjectState fromState) {
        this.fromState = fromState;
    }

    public ProjectState getToState() {
        return toState;
    }

    public void setToState(ProjectState toState) {
        this.toState = toState;
    }

    public String getEventedBy() {
        return eventedBy;
    }

    public void setEventedBy(String eventedBy) {
        this.eventedBy = eventedBy;
    }

    public LocalDateTime getEvented() {
        return evented;
    }

    public void setEvented(LocalDateTime evented) {
        this.evented = evented;
    }

    @PrePersist
    protected void onPrePersist() {
        this.eventedBy = Context.getSession().getLoggedInUser().getId();
        this.evented = LocalDateTime.now();
    }

}
