package com.six.iiq.plugin.filetransfer.controller;

import com.six.iiq.plugin.filetransfer.Context;
import com.six.iiq.plugin.filetransfer.entities.User;
import com.six.iiq.plugin.filetransfer.repository.ProjectNoteRepository;
import com.six.iiq.plugin.filetransfer.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
public class UserController {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ProjectNoteRepository projectNoteRepository;

    @RequestMapping("/getLoggedInUser")
    public User getLoggedInUser() {

        return Context.getSession().getLoggedInUser();

    }

    @RequestMapping("/getUser")
    public User getUser(@RequestParam String id) {

        Optional<User> userOptional = userRepository.findById(id);

        if (userOptional.isPresent()) {
            return userOptional.get();
        }

        return null;

    }

}
