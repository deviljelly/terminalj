package com.six.iiq.plugin.filetransfer.enums;

public enum ProjectState {

    Design("Design"),
    Approval("Approval"),
    Approved("Approved"),
    Rejected("Rejected"),
    Submitted("Submitted"),
    Scheduled("Scheduled"),
    Running("Running"),
    Successful("Successful"),
    Failed("Failed"),
    Archived("Archived");

    public final String label;

    private ProjectState(String label) {
        this.label = label;
    }

}
