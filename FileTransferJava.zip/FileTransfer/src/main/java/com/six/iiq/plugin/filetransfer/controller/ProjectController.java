package com.six.iiq.plugin.filetransfer.controller;


import com.six.iiq.plugin.filetransfer.enums.ProjectState;
import com.six.iiq.plugin.filetransfer.entities.Project;
import com.six.iiq.plugin.filetransfer.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
public class ProjectController {

    @Autowired
    private ProjectRepository projectRepository;

    @RequestMapping("/getProject")
    public Project getProject(@RequestParam String projectId) {

        Optional<Project> optionalProject = projectRepository.findById(projectId);

        if(optionalProject.isPresent()) {
            return optionalProject.get();
        }

        return null;

    }

    @RequestMapping("/createProject")
    public Project createProject(@RequestBody Project project) {

        project.setProjectState(ProjectState.Design);

        Project newProject = projectRepository.save(project);

        System.out.println(newProject.getNumber());

        return projectRepository.save(newProject);

    }

    @RequestMapping("/getAppProjects")
    public List<Project> getAllProjectsForApp(@RequestParam String appId) {

        return projectRepository.findAllProjectsForApp(appId);

    }

    @RequestMapping("/updateProject")
    public Project updateProject(@RequestBody Project project) {

        return projectRepository.save(project);

    }

}
