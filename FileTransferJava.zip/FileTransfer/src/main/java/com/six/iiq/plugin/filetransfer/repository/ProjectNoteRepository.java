package com.six.iiq.plugin.filetransfer.repository;

import com.six.iiq.plugin.filetransfer.entities.Note;
import com.six.iiq.plugin.filetransfer.entities.ProjectNote;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;
import java.util.List;

public interface ProjectNoteRepository extends CrudRepository<ProjectNote, String> {

    @Query("SELECT n FROM Note n INNER JOIN ProjectNote pn ON n.id = pn.noteId WHERE pn.projectId = :projectId")
    public List<Note> findAllNotesForProject(@Param("projectId") String projectId);

    @Transactional
    @Modifying
    @Query("DELETE FROM ProjectNote WHERE noteId = :noteId")
    public void deleteByNoteId(@Param("noteId") String noteId);

}
