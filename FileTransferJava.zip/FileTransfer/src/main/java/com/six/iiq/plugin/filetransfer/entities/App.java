package com.six.iiq.plugin.filetransfer.entities;

import com.six.iiq.plugin.filetransfer.Context;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;

import javax.persistence.*;
import java.time.LocalDateTime;



@Entity
@Table(name = "app")
@Audited
@AuditTable("app_audit")
public class App {

    @Id
    @Column(name = "id", columnDefinition="CHAR(32)", nullable = false)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(
            name = "uuid",
            strategy = "uuid"
    )
    private String id;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "app_manager", columnDefinition="CHAR(32)", nullable = false)
    private String appManager;

    @Column(name = "created_by", columnDefinition="CHAR(32)", nullable = false)
    private String createdBy;

    @Column(name = "created", nullable = false)
    private LocalDateTime created;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "updated")
    private LocalDateTime updated;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAppManager() {
        return appManager;
    }

    public void setAppManager(String appManager) {
        this.appManager = appManager;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreated() {
        return created;
    }

    public void setCreated(LocalDateTime created) {
        this.created = created;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public LocalDateTime getUpdated() {
        return updated;
    }

    public void setUpdated(LocalDateTime updated) {
        this.updated = updated;
    }

    @PrePersist
    protected void onPrePersist() {
        this.createdBy = Context.getSession().getLoggedInUser().getId();
        this.created = LocalDateTime.now();
    }

    @PreUpdate
    protected void onPreUpdate() {
        this.updatedBy = Context.getSession().getLoggedInUser().getId();
        this.updated = LocalDateTime.now();
    }

}

