package com.six.iiq.plugin.filetransfer.controller;

import com.six.iiq.plugin.filetransfer.entities.Event;
import com.six.iiq.plugin.filetransfer.entities.Note;
import com.six.iiq.plugin.filetransfer.repository.NoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;


@RestController
public class NoteController {

    @Autowired
    private NoteRepository noteRepository;

    @RequestMapping("/createNote")
    public Note createNote() {

       Note newNote = noteRepository.save(new Note());

        return newNote;

    }

    @RequestMapping("/getNote")
    public Note getNote(@RequestParam String noteId) {

        Optional<Note> noteOptional = noteRepository.findById(noteId);

        if(noteOptional.isPresent()) {
            return noteOptional.get();
        }

        return null;

    }

    @RequestMapping("/updateNote")
    public Note updateNote(@RequestBody Note note) {

        Note updatedNote = noteRepository.save(note);

        return updatedNote;

    }

    @RequestMapping("/deleteNote")
    public void deleteNote(@RequestBody Note note) {

        noteRepository.delete(note);

    }

}
