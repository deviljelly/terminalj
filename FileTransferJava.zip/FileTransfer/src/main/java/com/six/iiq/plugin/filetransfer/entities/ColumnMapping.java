package com.six.iiq.plugin.filetransfer.entities;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.List;

public class ColumnMapping {

    private String from;
    private String to;

    public ColumnMapping() {
    }

    public ColumnMapping(String from, String to) {
        this.from = from;
        this.to = to;
    }

    public static String toJSON(List<ColumnMapping> columnMapping) {

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsString(columnMapping);
        } catch (JsonProcessingException jpe) {
            System.err.println(jpe);
        }

        return null;

    }

    public static List<ColumnMapping> fromJSON(String jsonString) {

        List<ColumnMapping> columnMappings = new ArrayList<>();
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            columnMappings = objectMapper.readValue(jsonString, new TypeReference<List<ColumnMapping>>() {
            });
        } catch (JsonProcessingException jpe) {
            System.err.println(jpe);
        }
        return columnMappings;

    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

}
