package com.six.iiq.plugin.filetransfer.controller;

import com.six.iiq.plugin.filetransfer.entities.Event;
import com.six.iiq.plugin.filetransfer.entities.Note;
import com.six.iiq.plugin.filetransfer.enums.EventType;
import com.six.iiq.plugin.filetransfer.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;



@RestController
public class EventController {

    @Autowired
    private EventRepository eventRepository;

    @RequestMapping("/getEventsBySubject")
    public List<Event> getEventsBySubject(@RequestParam String subjectId) {

        List<Event> events = eventRepository.findBySubject(subjectId);

        return events;

    }

    @RequestMapping("/getEventsByObject")
    public List<Event> getEventsByObject(@RequestParam String objectId) {

        List<Event> events = eventRepository.findByObject(objectId);

        return events;

    }

    @RequestMapping("/getEventsByType")
    public List<Event> getEventsByType(@RequestParam EventType eventType) {

        List<Event> events = eventRepository.findByType(eventType);

        return events;

    }



}
