package com.six.iiq.plugin.filetransfer.entities;

import com.six.iiq.plugin.filetransfer.Context;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "note")
@Audited
@AuditTable("note_audit")
public class Note {

    @Id
    @Column(name = "id", columnDefinition="CHAR(32)", nullable = false)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(
            name = "uuid",
            strategy = "uuid"
    )
    private String id;

    @Column(name = "title")
    private String title;

    @Column(name = "shared")
    private boolean shared;

    @Column(name = "body")
    private String body;

    @Column(name = "created_by", columnDefinition="CHAR(32)", nullable = false)
    private String createdBy;

    @Column(name = "created", nullable = false)
    private LocalDateTime created;

    @Column(name = "updated_by", columnDefinition="CHAR(32)")
    private String updatedBy;

    @Column(name = "updated")
    private LocalDateTime updated;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isShared() {
        return shared;
    }

    public void setShared(boolean shared) {
        this.shared = shared;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreated() {
        return created;
    }

    public void setCreated(LocalDateTime created) {
        this.created = created;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public LocalDateTime getUpdated() {
        return updated;
    }

    public void setUpdated(LocalDateTime updated) {
        this.updated = updated;
    }

    @PrePersist
    protected void onPrePersist() {
        this.createdBy = Context.getSession().getLoggedInUser().getId();
        this.created = LocalDateTime.now();
    }

    @PreUpdate
    protected void onPreUpdate() {
        this.updatedBy = Context.getSession().getLoggedInUser().getId();
        this.updated = LocalDateTime.now();
    }

}
