package com.six.iiq.plugin.filetransfer.enums;

public enum ProjectType {

    Entitlements("Entitlements"),
    Accounts("Accounts"),
    Assignments("Assignments");


    /*

UserEntitlements (Assignments)

    IdentityName
    ApplicationName
    EntitlementName

Entitlements

    ApplicationName
    EntitlementName
    Description
    OwnerName
    FulfillerName

Accounts

    IdentityName
    ApplicationName
    AccountStatus

     */

    public final String label;

    private ProjectType(String label) {
        this.label = label;
    }

}
