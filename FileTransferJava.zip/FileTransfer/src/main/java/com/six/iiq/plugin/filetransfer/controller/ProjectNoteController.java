package com.six.iiq.plugin.filetransfer.controller;


import com.six.iiq.plugin.filetransfer.entities.Event;
import com.six.iiq.plugin.filetransfer.entities.Note;
import com.six.iiq.plugin.filetransfer.entities.ProjectNote;
import com.six.iiq.plugin.filetransfer.enums.EventType;
import com.six.iiq.plugin.filetransfer.repository.EventRepository;
import com.six.iiq.plugin.filetransfer.repository.NoteRepository;
import com.six.iiq.plugin.filetransfer.repository.ProjectNoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ProjectNoteController {

    @Autowired
    private ProjectNoteRepository projectNoteRepository;
    @Autowired
    private NoteRepository noteRepository;
    @Autowired
    private EventRepository eventRepository;


    @RequestMapping("/createProjectNote")
    public Note createProjectNote(@RequestParam String projectId) {

        Note newNote = noteRepository.save(new Note());
        ProjectNote newProjectNote = new ProjectNote();

        newProjectNote.setProjectId(projectId);
        newProjectNote.setNoteId(newNote.getId());
        projectNoteRepository.save(newProjectNote);

        Event event = new Event();
        event.setEventType(EventType.NoteCreated);
        event.setSubjectId(projectId);
        event.setObjectId(newNote.getId());
        eventRepository.save(event);

        return newNote;

    }

    @RequestMapping("/getProjectNotes")
    public List<Note> getNotesForProject(@RequestParam String projectId) {

        List<Note> notesForProject = projectNoteRepository.findAllNotesForProject(projectId);

        return notesForProject;

    }

    @RequestMapping("/deleteProjectNote")
    public void deleteProjectNote(@RequestParam String projectId, @RequestParam String noteId) {

        projectNoteRepository.deleteByNoteId(noteId);
        noteRepository.deleteById(noteId);

        Event event = new Event();
        event.setEventType(EventType.NoteDeleted);
        event.setSubjectId(projectId);
        event.setObjectId(noteId);
        eventRepository.save(event);

    }

}
