package com.six.iiq.plugin.filetransfer.repository;

import com.six.iiq.plugin.filetransfer.entities.Note;
import org.springframework.data.repository.CrudRepository;

public interface NoteRepository extends CrudRepository<Note, String> {

}
