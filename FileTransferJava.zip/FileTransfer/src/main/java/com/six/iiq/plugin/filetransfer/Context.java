package com.six.iiq.plugin.filetransfer;

import com.six.iiq.plugin.filetransfer.entities.User;

public class Context {

    public static Context context;

    private User loggedInUser;

    public static Context getSession() {

        if(context ==null) {

            context = new Context();

            User loggedInUser = new User();

            loggedInUser.setId("ff80808176d8c0e40176d8c10e240004");
            loggedInUser.setUserId("tka45");
            loggedInUser.setUserName("Paul Anderson");
            loggedInUser.setDisplayableName("Paul Anderson");
            context.setLoggedInUser(loggedInUser);

        }

        return context;

    }

    public User getLoggedInUser() {
        return loggedInUser;
    }

    public void setLoggedInUser(User loggedInUser) {
        this.loggedInUser = loggedInUser;
    }

}
