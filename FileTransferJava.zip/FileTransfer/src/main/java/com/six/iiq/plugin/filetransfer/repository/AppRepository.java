package com.six.iiq.plugin.filetransfer.repository;

import com.six.iiq.plugin.filetransfer.entities.App;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AppRepository extends CrudRepository<App, String> {

    @Query("SELECT a FROM App a WHERE a.appManager = :userId")
    public List<App> findAllAppsForUser(@Param("userId") String userId);

}
